import 'package:video_player/video_player.dart';
class Ctr{
 VideoPlayerController controller;

}