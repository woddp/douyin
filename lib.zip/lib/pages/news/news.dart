import 'package:flutter/material.dart';

class News extends StatefulWidget{
  @override
  _NewsState createState()=>new _NewsState();
}

class _NewsState extends State<News>{

  @override
  Widget build(BuildContext context) {
    // TODO: implement build
    return new Align(
      child: Text('1'),
    );
  }
}