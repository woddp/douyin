import 'package:flutter/material.dart';
import 'package:flutter_douyin/pages/home/player.dart';
import '../common/wAppBar.dart';
import 'head.dart';
import 'dart:async';
import 'package:video_player/video_player.dart';
class Home extends StatefulWidget {
  @override
  _HomeState createState() => new _HomeState();
}

class _HomeState extends State<Home>  with SingleTickerProviderStateMixin {
  AnimationController _controller;
  Animation<double> _animation;
  double moveY = 0.0;

  bool isUp = false; //向上滑动
  bool isDown = false; //向下滑动

  bool islock = false; //锁定方向

  int prevIndex = 0;
  int listLength = 0;
  int curIndex = 0;

  //最后高度
  double lastPostion = 0.0;

  //
  bool forward = true;

  //播放器对象
  Function playFunction = null;

  List<Map<String, String>> list = [
    {
      "img": "http://woddp.yxilin.com/static/mp4/1.jpg",
      "url": "http://qiy.woddp.yxilin.com/3.mp4",
    },
    {
      "img": "http://woddp.yxilin.com/static/mp4/2.jpg",
      "url": "http://qiy.woddp.yxilin.com/2.mp4",
    },
    {
      "img": "http://woddp.yxilin.com/static/mp4/3.jpg",
      "url": "http://qiy.woddp.yxilin.com/1.mp4",
    }
  ];

  @override
  void initState() {
    setState(() {
      listLength = list.length - 1;
      prevIndex = 1;
      curIndex = 0;
    });
    super.initState();

    run();
  }

  void run() {
    _controller =
        new AnimationController(vsync: this, duration: Duration(seconds: 3));

    _animation = new Tween(begin: 100.0, end: 0.0).animate(_controller);
    _animation.addListener(() {});
//    _controller.forward();
  }

  ///向上滑动重置
  void resetTopIndex() {
    setState(() {
      //如果当前索引等余总条数
      if (curIndex == listLength) {
        prevIndex = 0; //上一条减去1
//        curIndex=0;
      }
      //如果当前索引小于总条数
      if (curIndex < listLength) {
        prevIndex = curIndex + 1; //当前加1
      }
    });
  }

  ///向下滑动重置
  void resetDownIndex() {
    setState(() {
      //如果当前索引等余总条数
      if (curIndex == listLength) {
        prevIndex = curIndex - 1; //上一条减去1
      }
      if (curIndex == 0) {
        prevIndex = listLength;
      }
      //如果当前索引小于总条数
      if (curIndex < listLength && curIndex > 0) {
        prevIndex = curIndex - 1; //当前减去1
      }
    });
  }

  ///按下滑动
  void dragStart(e) {
    setState(() {
      moveY = moveY + e.delta.dy;
    });

//    print("移动距离：" + moveY.toString());
//    print("触摸距离：" + e.delta.dy.toString());
    ///向上滑动
    if (e.delta.dy < 0) {
//      print("向上");
      //向上滑动重置前后索引
      if (moveY < 0) {
        resetTopIndex();
      }
      if (moveY.abs() > 200) {
        setState(() {
          isUp = true;
          isDown = false;
        });
      }
      if (moveY.abs() < 200) {
        setState(() {
          isUp = false;
          isDown = false;
        });
      }
    }

    ///向下滑动
    if (e.delta.dy > 0) {
//      print("向下");
      if (moveY > 0) {
        resetDownIndex();
      }
      if (moveY.abs() > 200) {
        setState(() {
          isUp = false;
          isDown = true;
        });
      }
      if (moveY.abs() < 200) {
        setState(() {
          isUp = false;
          isDown = false;
        });
      }
    }
  }

  //按下离开
  void dragEnd(e) {
    if (isUp) {
      if (curIndex < listLength) {
        setState(() {
          int tempPrevIndex = prevIndex + 1;
          if (tempPrevIndex < listLength) {
            prevIndex = tempPrevIndex;
          }
          curIndex++;
          isUp = false;
        });
      } else {
        curIndex = 0;
      }
      playFunction(list[curIndex]['url']);
    }
    if (isDown) {
      if (curIndex > 0) {
        setState(() {
          int tempPrevIndex = prevIndex - 1;
//          print(tempPrevIndex);
          if (tempPrevIndex > 0) {
            prevIndex = tempPrevIndex;
          }
          curIndex -= 1;
          isUp = false;
        });
      } else {
        curIndex = listLength;
      }
      playFunction(list[curIndex]['url']);
    }
    setState(() {
      moveY = _controller.value;
    });
  }

  @override
  Widget build(BuildContext context) {
    // TODO: implement build
    return new Scaffold(
//      appBar: WAppBar(
//        primary:false,
//        backgroundColor: Colors.transparent,
//        toolbarOpacity: 0.0,
//        bottomOpacity: 0.0,
//        child: new Container(
//
//        ),
//      ),
      body: new ConstrainedBox(
        //ConstrainedBox 限制容器
        constraints: BoxConstraints.expand(),
        child: new Stack(
          children: <Widget>[
            Container(
              child: new Center(
                child: new Image.network(
                  list[prevIndex]['img'],
                ),
              ),
              color: Colors.black,
              height: double.maxFinite,
              width: double.maxFinite,
            ),
            Transform.translate(
                offset: Offset(0.0, moveY),
                child: new GestureDetector(
                  onVerticalDragStart: (e) {},
                  onVerticalDragUpdate: (e) {
                    dragStart(e);
                  },
                  onVerticalDragEnd: (e) {
                    dragEnd(e);
                  },
                  child: new Container(
                    child: Center(
                      child: new Player(
                        onPlayer: (startPlay) {
                          playFunction = startPlay;
                          playFunction(list[curIndex]['url']);
                        },
                      ),
                    ),
                    decoration: new BoxDecoration(
                        image: new DecorationImage(
                          image: new NetworkImage(
                            list[curIndex]['img'],
                          ),
                        ),
                        color: Theme.of(context).backgroundColor),
                  ),
                )),
                new Head(),
          ],
        ),
      ),
    );
  }

  @override
  void dispose() {
    // TODO: implement dispose
    _controller.dispose();
    super.dispose();
  }
}
